--<ScriptOptions statementTerminator=";"/>
insert into APP.USUARIO (usuario,senha) values ('teste1','teste1');
insert into APP.USUARIO (usuario,senha) values ('teste2','teste2');

INSERT INTO APP.PESSOA (NOME, SOBRENOME) VALUES ('Pessoa','Teste 1');
INSERT INTO APP.PESSOA (NOME, SOBRENOME) VALUES ('Pessoa','Teste 2');
