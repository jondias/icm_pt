package org.icm.entity;

import java.io.Serializable;

//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;


//@Entity
//@Table(name="APP.USUARIO")
public class UsuarioEntity implements Serializable {
	
	private static final long serialVersionUID = -705980999884729289L;
	
	private String user;
	private String password;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	//@Id
	//@Column(name="usuario")
	public String getUsuario() {
		return this.getUser();
	}
	
	public void setUsuario(String usuario) {
		this.setUser(usuario);
	}
	
	//@Column(name="senha")
	public String getSenha() {
		return this.getPassword();
	}
	public void setSenha(String password) {
		this.setPassword(password);
	}

}
