package org.icm.utils;


public class NavigationRules {
	
	public static final String LOGIN = "login";
	public static final String LOGIN_ERROR = "login_error";
	public static final String CADASTRAR_MEMBRO = "cadastrar_membro";
	public static final String WELCOME = "welcome";

}
