package org.icm.bean;

import java.io.Serializable;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.icm.entity.UsuarioEntity;
import org.icm.utils.NavigationRules;

@Named("usuarioBean")
@SessionScoped
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class UsuarioBean implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Inject
	private MembroBean membroBean;
	
	//@Inject
	private UsuarioEntity utilizador = new UsuarioEntity();
	
	public UsuarioBean() {
		
	}
	
	public String validation() {
		try {
			/*if (userValidation == null) {
				Context ctx = new InitialContext();
				userValidation = (UserService) ctx.lookup("java:global/ICM_EAR_Tutorial/ICM_EJB/UserServiceBean!org.icm.ejb.UserService");
			}
			
			if (userValidation.validar((UsuarioVO) this)) {
				return NavigationRules.LOGIN;
			}*/
			//throw new ValidationException();
			utilizador.setUser("Utilizador Adm");
			return NavigationRules.LOGIN;
		} catch (Throwable t) {
			System.err.println("Erro Grave no Login");
			t.printStackTrace();
		}
		
		return NavigationRules.LOGIN_ERROR;
	}

	public UsuarioEntity getUtilizador() {
		return utilizador;
	}

	public void setUtilizador(UsuarioEntity utilizador) {
		this.utilizador = utilizador;
	}

	public MembroBean getMembroBean() {
		return membroBean;
	}

	public void setMembroBean(MembroBean membroBean) {
		this.membroBean = membroBean;
	}

}
