package org.icm.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;

import org.icm.entity.MembroEntity;
import org.icm.utils.NavigationRules;
import org.icm.vo.MembroVO;

@Named("membroBean")
@ViewScoped
@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class MembroBean extends MembroVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2259489081400381392L;

	private static List<String> funcoes;
	
	//@Inject
	private MembroEntity membroEntity;
	
	public MembroBean () {
		
	}
	
	public String salvar() {
		try {
			/*if (membroService == null) {
				Context ctx = new InitialContext();
				membroService = (MembroService) ctx.lookup("java:global/ICM_EAR_Tutorial/ICM_EJB/MembroServiceBean!org.icm.ejb.MembroService");
			}
			
			MembroVO membroVo = new MembroVO();
			membroVo.setNome(this.getNome());
			membroVo.setApelido(this.getApelido());
			if (membroService.salvar(membroVo)) {
				return NavigationRules.WELCOME;
			}*/
			//throw new ValidationException();
		} catch (Throwable t) {
			System.err.println("Erro Grave no Login");
			t.printStackTrace();
		}
		
		return NavigationRules.WELCOME;
	}

	public MembroEntity getMembroEntity() {
		return membroEntity;
	}

	public void setMembroEntity(MembroEntity membroEntity) {
		this.membroEntity = membroEntity;
	}
	
	public List<String> getFuncoes() {
		if(funcoes == null || funcoes.isEmpty()) {
			funcoes = new ArrayList<>();
			funcoes.add("Obreiro");
			funcoes.add("Di�cono");
			funcoes.add("Pastor");
			funcoes.add("Instrumentista");
			funcoes.add("Dirigente");
		}
		return funcoes;
	}

	public static void setFuncoes(List<String> funcoes) {
		MembroBean.funcoes = funcoes;
	}

}
