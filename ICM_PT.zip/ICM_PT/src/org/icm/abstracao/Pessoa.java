package org.icm.abstracao;

/*import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.TableGenerator;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;*/


//@MappedSuperclass
public abstract class Pessoa {
	
	/*@TableGenerator(
		    name="pessoa_id",
		    table="PERSISTENCE_ORDER_SEQUENCE_GENERATOR",
		    pkColumnName="GEN_KEY",
		    valueColumnName="GEN_VALUE",
		    pkColumnValue="VENDOR_PART_ID",
		    allocationSize=10)
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator="pessoa_id")
	@Column(name = "PESSOAID", updatable = false, nullable = false)*/
	private Integer bi;
	
	//@Column(name = "NOME", nullable = false)
	private String nomeCompleto;
	
	private String morada;
	
	public Integer getPessoaid() {
		return bi;
	}
	public void setPessoaid(Integer pessoaid) {
		this.bi = pessoaid;
	}
	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}
	public String getMorada() {
		return morada;
	}
	public void setMorada(String morada) {
		this.morada = morada;
	}

}
